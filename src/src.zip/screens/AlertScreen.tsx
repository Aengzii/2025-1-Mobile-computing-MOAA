// src/screens/AlertScreen.tsx
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
} from 'react-native';
// import { COLORS } from '../constants/colors';

// 임시 상수
const COLORS = {
    background: '#FFFFFF',
    gray200: '#EEE',
    gray900: '#131313',
    gray500: '#AAA',
};

// ⭐️ 'export' 키워드를 여기서 제거했습니다.
const AlertScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>알림</Text>
      </View>
      <View style={styles.content}>
        <Text style={styles.placeholderText}>알림 화면 준비 중입니다</Text>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.gray200,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.gray900,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholderText: {
    fontSize: 16,
    color: COLORS.gray500,
  },
});

// ⭐️ 파일 맨 아래에 이 줄을 추가했습니다.
export default AlertScreen;