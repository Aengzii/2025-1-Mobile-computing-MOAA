// src/screens/MainScreen.tsx
import React, { useState, useCallback } from 'react';
import {
  View,
  ScrollView,
  TouchableOpacity,
  Image,
  StyleSheet,
  Text,
  SafeAreaView,
  FlatList,
  ListRenderItem,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getAllGifticons, getAllCategories, Gifticon, Category } from '../services/gifticonService';
import { COLORS } from '../constants/colors';
import { TYPOGRAPHY } from '../constants/typography';

// =================================================================
// 1. 헬퍼 함수 및 하위 컴포넌트 정의
// =================================================================
const getKoreanToday = (): Date => {
  const now = new Date();
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  const koreaOffset = 9 * 60 * 60000;
  return new Date(new Date(utc + koreaOffset).setHours(0, 0, 0, 0));
};

const HeaderInfo = ({ count, onAlertClick }: { count: number; onAlertClick: () => void; }) => (
    <View style={styles.header_container}>
        <View>
            <Text style={styles.header_line1}>사용 가능한 기프티콘이</Text>
            <Text style={styles.header_line2}>{count.toString().padStart(2, '0')}개 남아있어요.</Text>
        </View>
        <TouchableOpacity onPress={onAlertClick}>
            <Image source={require('../assets/images/yesAlarm.png')} style={styles.header_icon} />
        </TouchableOpacity>
    </View>
);

const GifticonTab = ({ tab, setTab, availableCount, usedCount }: any) => (
  <View style={styles.tab_container}>
    <TouchableOpacity style={styles.tab_button} onPress={() => setTab('available')}>
      <Text style={tab === 'available' ? styles.tab_activeText : styles.tab_inactiveText}>
        사용 가능 {availableCount}
      </Text>
      {tab === 'available' && <View style={styles.tab_underline} />}
    </TouchableOpacity>
    <TouchableOpacity style={styles.tab_button} onPress={() => setTab('used')}>
      <Text style={tab === 'used' ? styles.tab_activeText : styles.tab_inactiveText}>
        사용 완료 {usedCount}
      </Text>
      {tab === 'used' && <View style={styles.tab_underline} />}
    </TouchableOpacity>
  </View>
);

const GifticonCategoryFilter = ({ category, setCategory, categories }: any) => (
  <View>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{paddingVertical: 8}}>
      <TouchableOpacity style={styles.category_addButton}>
        <Text style={styles.category_addButtonText}>＋</Text>
      </TouchableOpacity>
      {categories.map((cat: string) => (
        <TouchableOpacity
          key={cat}
          style={[styles.category_button, cat === category ? styles.category_active : styles.category_inactive]}
          onPress={() => setCategory(cat)}
        >
          <Text style={[styles.category_text, cat === category ? styles.category_activeText : styles.category_inactiveText]}>
            {cat}
          </Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  </View>
);

const GifticonSortSelector = ({ sortOption }: { sortOption: string }) => (
    <TouchableOpacity style={styles.sort_button}>
        <Text style={styles.sort_buttonText}>{sortOption}</Text>
        <Text style={styles.sort_chevron}>▼</Text>
    </TouchableOpacity>
);

const GifticonCard = ({ gifticon }: { gifticon: Gifticon }) => {
    const today = getKoreanToday();
    const expireDate = new Date(new Date(gifticon.expireDate).setHours(0, 0, 0, 0));
    const diffDays = Math.ceil((expireDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return (
        <View style={styles.card_item}>
            <View style={styles.card_imageWrapper}>
                <Image source={{uri: gifticon.image || 'https://via.placeholder.com/150'}} style={styles.card_image} />
                <View style={styles.card_badge}><Text style={styles.card_badgeText}>D-{diffDays}</Text></View>
            </View>
            <View style={styles.card_info}>
                <Text style={styles.card_brand} numberOfLines={1}>{gifticon.brand}</Text>
                <Text style={styles.card_title} numberOfLines={1}>{gifticon.title}</Text>
                <Text style={styles.card_date}>{new Date(gifticon.expireDate).toLocaleDateString('ko-KR')}</Text>
            </View>
        </View>
    );
};

const GifticonListItem = ({ gifticon }: { gifticon: Gifticon }) => {
    return <View><Text>{gifticon.title}</Text></View>;
};

const GifticonGrid = ({ gifticons, viewMode, navigation, onRefresh, refreshing }: { gifticons: Gifticon[]; viewMode: 'card'|'list'; navigation: any; onRefresh: () => void; refreshing: boolean; }) => {
  
  const renderItem: ListRenderItem<Gifticon> = ({ item }) => {
    const content = viewMode === 'card' 
      ? <GifticonCard gifticon={item} />
      : <GifticonListItem gifticon={item} />;

    return (
      <TouchableOpacity onPress={() => navigation.navigate('Detail', { gifticonId: item.id })}>
        {content}
      </TouchableOpacity>
    );
  };
  
  return (
    <FlatList
      data={gifticons}
      keyExtractor={item => item.id.toString()}
      renderItem={renderItem}
      numColumns={viewMode === 'card' ? 2 : 1}
      showsVerticalScrollIndicator={false}
      columnWrapperStyle={viewMode === 'card' ? { justifyContent: 'space-between' } : undefined}
      onRefresh={onRefresh}
      refreshing={refreshing}
    />
  );
};

const GifticonEmptyState = () => (
    <View style={styles.empty_container}>
        <Text style={styles.empty_text}>사용 가능한 기프티콘이 없어요</Text>
    </View>
);


// =================================================================
// 3. 메인 컴포넌트
// =================================================================
const MainScreen = ({ navigation }: any) => {
  const [tab, setTab] = useState<'available' | 'used'>('available');
  const [viewMode, setViewMode] = useState<'card' | 'list'>('card');
  const [category, setCategory] = useState<string>('전체');
  const [sortOption, setSortOption] = useState<string>('유효기간 순');
  
  const [gifticons, setGifticons] = useState<Gifticon[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const [loadedGifticons, loadedCategories] = await Promise.all([
        getAllGifticons(),
        getAllCategories(),
      ]);
      setGifticons(loadedGifticons);
      setCategories(loadedCategories);
    } catch (error) {
      console.error("메인 화면 데이터 로딩 실패:", error);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData])
  );

  const onRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await loadData();
    setIsRefreshing(false);
  }, [loadData]);


  const today = getKoreanToday();
  const availableGifticons = gifticons.filter(g => !g.used && new Date(g.expireDate).getTime() >= today.getTime());
  const usedGifticons = gifticons.filter(g => g.used || new Date(g.expireDate).getTime() < today.getTime());

  const filteredByTab = tab === 'available' ? availableGifticons : usedGifticons;
  const filteredGifticons = category === '전체' ? filteredByTab : filteredByTab.filter(g => g.category === category);
  const sortedGifticons = [...filteredGifticons].sort((a, b) => {
    if (sortOption === '유효기간 순') return new Date(a.expireDate).getTime() - new Date(b.expireDate).getTime();
    if (sortOption === '금액 순') return b.price - a.price;
    if (sortOption === '등록날짜 순') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    return 0;
  });

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.headerWrapper}>
        <HeaderInfo count={availableGifticons.length} onAlertClick={() => navigation.navigate('Alert')} />
        <GifticonTab tab={tab} setTab={setTab} availableCount={availableGifticons.length} usedCount={usedGifticons.length} />
      </View>

      <View style={styles.contentWrapper}>
        <GifticonCategoryFilter 
          category={category} 
          setCategory={setCategory} 
          categories={['전체', ...categories.map(c => c.name)]} 
        />
        
        <View style={styles.toolbarWrapper}>
            <GifticonSortSelector sortOption={sortOption} />
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <TouchableOpacity onPress={() => navigation.navigate('Search', { gifticons })}>
                  <Image source={require('../assets/images/searchIcon.png')} style={styles.toolbarIcon} />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setViewMode(v => v === 'card' ? 'list' : 'card')}>
                    <Image 
                      source={viewMode === 'card' 
                        ? require('../assets/images/cardButton.png') 
                        : require('../assets/images/listButton.png')} 
                      style={styles.toolbarIcon} 
                    />
                </TouchableOpacity>
            </View>
        </View>

        {sortedGifticons.length > 0 ? (
          <GifticonGrid 
            gifticons={sortedGifticons} 
            viewMode={viewMode}
            navigation={navigation} 
            onRefresh={onRefresh}
            refreshing={isRefreshing}
          />
        ) : (
          <GifticonEmptyState />
        )}
      </View>
    </SafeAreaView>
  );
};

// =================================================================
// 4. 모든 스타일 정의
// =================================================================
const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: COLORS.white0 },
    headerWrapper: { paddingHorizontal: 16, backgroundColor: COLORS.white0, },
    contentWrapper: { flex: 1, paddingHorizontal: 16, },
    toolbarWrapper: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, },
    toolbarIcon: { width: 24, height: 24, marginLeft: 16 },
    header_container: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 20, paddingBottom: 16, },
    header_line1: { fontSize: 20, color: COLORS.gray8 },
    header_line2: { fontSize: 20, color: COLORS.gray8, fontWeight: 'bold' },
    header_icon: { width: 28, height: 28 },
    tab_container: { height: 59, borderBottomWidth: 1, borderBottomColor: '#EEE', flexDirection: 'row', },
    tab_button: { flex: 1, justifyContent: 'center', alignItems: 'center', },
    tab_activeText: { fontSize: 16, lineHeight: 16, fontWeight: '700', color: '#131313', },
    tab_inactiveText: { fontSize: 16, lineHeight: 16, fontWeight: '500', color: '#808080', },
    tab_underline: { position: 'absolute', bottom: 0, width: 122, height: 1, backgroundColor: '#F46127', },
    category_addButton: { width: 32, height: 32, borderRadius: 16, backgroundColor: COLORS.gray2, justifyContent: 'center', alignItems: 'center', marginRight: 8, },
    category_addButtonText: { fontSize: 16, color: COLORS.gray6 },
    category_button: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 18, marginRight: 8 },
    category_active: { backgroundColor: COLORS.main },
    category_inactive: { backgroundColor: COLORS.gray2 },
    category_text: { fontSize: 14, fontWeight: '500' },
    category_activeText: { color: COLORS.white0 },
    category_inactiveText: { color: COLORS.gray6 },
    sort_button: { flexDirection: 'row', alignItems: 'center' },
    sort_buttonText: { color: COLORS.gray8, fontSize: 14 },
    sort_chevron: { marginLeft: 4, fontSize: 10, color: COLORS.gray8 },
    card_item: { width: '48%', marginBottom: 16, },
    card_imageWrapper: { width: '100%', aspectRatio: 1, borderRadius: 8, position: 'relative', overflow: 'hidden', backgroundColor: '#F0F0F0' },
    card_image: { width: '100%', height: '100%' },
    card_badge: { position: 'absolute', top: 8, left: 8, backgroundColor: COLORS.main, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4 },
    card_badgeText: { color: COLORS.white0, fontSize: 12, fontWeight: 'bold' },
    card_info: { marginTop: 8 },
    card_brand: { fontSize: 12, color: COLORS.gray6 },
    card_title: { fontSize: 14, color: COLORS.gray8, fontWeight: '500', marginVertical: 2 },
    card_date: { fontSize: 12, color: COLORS.gray6 },
    empty_container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    empty_text: { fontSize: 16, color: COLORS.gray5 },
});

export default MainScreen;