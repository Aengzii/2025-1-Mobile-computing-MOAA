// src/screens/NotificationSettingScreen.tsx
import React, { useState, useEffect } from 'react';
import { View, Text, Switch, StyleSheet, Button, FlatList, TouchableOpacity, Modal } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';

let nextId = 1000;

const NotificationSettingScreen = ({
  isNotificationEnabled,
  setIsNotificationEnabled,
  alertSettings,
  setAlertSettings,
  onBack,
}: any) => {
  const [modalOpen, setModalOpen] = useState(false);

  const handleToggle = () => {
    setIsNotificationEnabled(!isNotificationEnabled);
  };

  const handleAddAlert = (alert: any) => {
  // alertSettings가 undefined일 경우 빈 배열 []을 사용하도록 수정
  setAlertSettings([...(alertSettings || []), { ...alert, id: nextId++ }]);
};

  const handleDeleteAlert = (id: number) => {
    setAlertSettings(alertSettings.filter((alert: any) => alert.id !== id));
  };

  return (
    <View style={styles.container}>
      {/* 상단 바 */}
      <View style={styles.titleBar}>
        <TouchableOpacity onPress={onBack} style={styles.backButton}>
          <Ionicons name="arrow-back" size={20} color="#000000" />
        </TouchableOpacity>
        <Text style={styles.titleText}>알림 설정</Text>
      </View>

      {/* 알림 허용 스위치 */}
      <View style={styles.card}>
        <Text style={styles.title}>알림 허용</Text>
        <Switch value={isNotificationEnabled} onValueChange={handleToggle} />
      </View>

      {/* 알림 리스트 */}
      {isNotificationEnabled && (
        <FlatList
          data={alertSettings}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.alertItem}>
              <Text>{item.title}</Text>
              <TouchableOpacity onPress={() => handleDeleteAlert(item.id)}>
                <Ionicons name="trash" size={20} color="red" />
              </TouchableOpacity>
            </View>
          )}
        />
      )}

      {/* 알림 추가 모달 */}
      <Modal visible={modalOpen} animationType="slide">
        <View style={styles.modalContainer}>
          <Text>새 알림 추가</Text>
          <Button title="추가" onPress={() => handleAddAlert({ title: '새 알림' })} />
          <Button title="닫기" onPress={() => setModalOpen(false)} />
        </View>
      </Modal>

      <Button title="알림 추가" onPress={() => setModalOpen(true)} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#F8F8F8' },
  titleBar: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 24 },
  backButton: { padding: 8 },
  titleText: { fontSize: 24, fontWeight: '900', color: '#000000' },
  card: { backgroundColor: '#FFFFFF', padding: 16, marginBottom: 24, borderRadius: 12, flexDirection: 'row', justifyContent: 'space-between' },
  title: { fontSize: 16, fontWeight: '600', color: '#131313' },
  alertItem: { padding: 16, backgroundColor: '#FFF', borderRadius: 10, marginBottom: 8, flexDirection: 'row', justifyContent: 'space-between' },
  modalContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});

export default NotificationSettingScreen;
