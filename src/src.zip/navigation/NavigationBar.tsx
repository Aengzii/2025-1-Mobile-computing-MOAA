import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from './AppNavigator';

// 1. 필요한 아이콘 세트를 import 합니다.
import Icon from 'react-native-vector-icons/Ionicons';
import MaterialCommunityIcon from 'react-native-vector-icons/MaterialCommunityIcons';

const NavigationBar = ({ state, descriptors, navigation: tabNavigation }: BottomTabBarProps) => {
  const stackNavigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();

  return (
    <View style={styles.container}>
      <TouchableOpacity
        accessibilityRole="button"
        onPress={() => stackNavigation.navigate('AutoScan')}
        style={styles.addButtonContainer}
      >
        <View style={styles.addButtonCircle}>
          {/* 2. 요청하신 디자인에 맞는 아이콘으로 교체하고, 색상을 수정합니다. */}
          <MaterialCommunityIcon name="folder-plus-outline" size={32} color="#FFFFFF" />
        </View>
      </TouchableOpacity>

      <View style={styles.tabBar}>
        {state.routes.map((route, index) => {
          const { options } = descriptors[route.key];
          const label = options.title !== undefined ? options.title : route.name;
          const isFocused = state.index === index;

          const onPress = () => {
            const event = tabNavigation.emit({
              type: 'tabPress',
              target: route.key,
              canPreventDefault: true,
            });

            if (!isFocused && !event.defaultPrevented) {
              tabNavigation.navigate(route.name, route.params);
            }
          };

          const onLongPress = () => {
            tabNavigation.emit({
              type: 'tabLongPress',
              target: route.key,
            });
          };
          
          const iconColor = isFocused ? '#C62880' : '#3E3E3E';

          const getIcon = () => {
            let iconName: string;
            if (route.name === 'MainTab') {
              iconName = isFocused ? 'wallet' : 'wallet-outline';
            } else if (route.name === 'MyPageTab') {
              iconName = isFocused ? 'person' : 'person-outline';
            } else {
              return null;
            }
            return <Icon name={iconName} size={24} color={iconColor} />;
          };
          
          if (route.name === 'Add') {
            return <View key="add-button-placeholder" style={styles.placeholder} />;
          }

          return (
            <TouchableOpacity
              key={route.key}
              accessibilityRole="button"
              accessibilityState={isFocused ? { selected: true } : {}}
              accessibilityLabel={options.tabBarAccessibilityLabel}
              testID={options.tabBarTestID}
              onPress={onPress}
              onLongPress={onLongPress}
              style={styles.tabButton}
            >
              {getIcon()}
              <Text style={[styles.labelText, { color: iconColor }]}>{label}</Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 100,
    alignItems: 'center',
  },
  tabBar: {
    flexDirection: 'row',
    width: '100%',
    height: 83,
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 48,
    borderTopRightRadius: 48,
    alignItems: 'center',
    justifyContent: 'space-around',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 10,
  },
  tabButton: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 8,
    paddingBottom: Platform.OS === 'ios' ? 16 : 8,
  },
  labelText: {
    fontSize: 10,
    fontWeight: '500',
    marginTop: 4,
  },
  addButtonContainer: {
    position: 'absolute',
    top: 0,
    zIndex: 1,
  },
  addButtonCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#C62880',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  placeholder: {
    flex: 1,
  },
});

export default NavigationBar;